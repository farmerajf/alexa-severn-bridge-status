# alexa-severn-crossing-status
An Alexa skill to report on the status of both Severn Bridges

# Useful links
https://github.com/alexa/alexa-skills-kit-sdk-for-nodejs
